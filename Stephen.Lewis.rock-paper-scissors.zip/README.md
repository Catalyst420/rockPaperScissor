## ROCK PAPER SCISSORS

#Technology Used in the Creation of this "THING"
I used my Apple OS with Visual Studio Code to edit the front end delopment. As well I used Affinity Designer application the edit my images and export them  to the applications front end code design.

# How to install/operate
1)Download files 
2)Double click zipped folder
3)Drag/drop (or open files via known path) in your favorite editor application
4)then open favorite browser (Chrome, FireFox)
5)Drag/drop (or open files via known path) into your browser
6)Refer to game play instructions from here

# Gameplay
In this childhood game one may chose rock, paper, or scissors. 
Rock beats Scissors (to win)
Scissors cuts Paper (to win)
Paper covers Rock (to win)
1)Click your choice to start playing
2)Once you chose the computer will chose
3)Then you will either win or lose
4)The score will be tallied at the bottom
5)To play another round, click play agian (score will be saved)
6)To continue to play, start back at step 1
7) To reset score and start over, refresh your browser window

# Rock Paper Scissors Development
Stephen Lewis - Front-End Design and Programing Specialist 
    Jarreau Mclemore - Visual Consultant
        Michael Siminski - Beta Testing and Visual Consultant
        Christopher Lovelace - Operation Consultant

# Graphic Design 
The actual image was screen shot from a graphic design video I liked. The thought was "What better for rock, paper, scissors than an all seeing hand of the 3rd eye varity." So needless to say that I was inspired when i saw it. I chose the dark green back ground because I feel it went with the image really well. Also the red for the text was the complementary color. So easy choice their. I put text shadow on the letters to make them pop, and it made them easier to read. Needless to say(but I will say it anyways) their is quite a bit of color and I had a moment of clashing colors. The shadow fixed it real well. 

# Gratitude
Here is where a developer would put his thanks, so now i will thank my buddies who put up with me for the days i spent on this. Calling them to look at this and that and their ideas of what they thought. As little or large as the idea may havve been it was a help.